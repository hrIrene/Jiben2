package com.tfs.first;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/de")
public class de extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID=1L;

    public de(){

    }
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response)
            throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }



    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response)
            throws javax.servlet.ServletException, IOException {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().println("hello  同学");
    }



    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.service(req, resp);
        System.out.println("service()...");
    }

    @Override
    public void destroy() {
        super.destroy();
        System.out.println("destroy()...");
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init();
        System.out.println("init()...");
        long start=System.currentTimeMillis();
        System.out.println("从磁盘读取城市信息");
        try{
            Thread.sleep(20000);
        }catch (InterruptedException e){
            e.printStackTrace();
        };
    }

}
